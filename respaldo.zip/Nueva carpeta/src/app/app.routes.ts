import { NgModule }             from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import { PrincipalComponent } from './principal/principal.component';


const APP_ROUTES: Routes = [
    {path: 'principal', component: PrincipalComponent },         
    {path: '**', pathMatch: 'full', redirectTo: 'principal'}
];

export const APP_ROUTING = RouterModule.forRoot(APP_ROUTES, {useHash: true, scrollPositionRestoration: 'enabled'});