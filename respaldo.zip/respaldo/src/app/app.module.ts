import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { PrincipalComponent } from './principal/principal.component';
import { RouterModule } from '@angular/router';
import { APP_ROUTING } from './app.routes';
import { NavbarComponent } from './navbar/navbar.component';
import { Trim2Component } from './trim2/trim2.component';
import { Trim3Component } from './trim3/trim3.component';
import { Trim1Component } from './trim1/trim1.component';
import { LoginComponent } from './login/login.component';

@NgModule({
  declarations: [
    AppComponent,
    PrincipalComponent,
    NavbarComponent,
    Trim2Component,
    Trim3Component,
    Trim1Component,
    LoginComponent    
  ],
  imports: [
    BrowserModule,
    RouterModule,
    APP_ROUTING
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
