import { NgModule }             from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import { PrincipalComponent } from './principal/principal.component';
import { Trim2Component } from './trim2/trim2.component';
import { Trim3Component } from './trim3/trim3.component';
import { Trim1Component } from './trim1/trim1.component';

const APP_ROUTES: Routes = [
    {path: 'principal', component: PrincipalComponent },  
    {path: 'trim2', component: Trim2Component },
    {path: 'trim3', component: Trim3Component },  
    {path: 'trim1', component: Trim3Component },     
    {path: '**', pathMatch: 'full', redirectTo: 'principal'}
];

export const APP_ROUTING = RouterModule.forRoot(APP_ROUTES, {useHash: true, scrollPositionRestoration: 'enabled'});