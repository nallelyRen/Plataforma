import { NgModule }             from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import { PrincipalComponent } from './principal/principal.component';
import { A1Component } from './a1/a1.component';

const APP_ROUTES: Routes = [
    {path: 'principal', component: PrincipalComponent },  
    {path: 'a1', component: A1Component },        
    {path: '**', pathMatch: 'full', redirectTo: 'principal'}
];

export const APP_ROUTING = RouterModule.forRoot(APP_ROUTES, {useHash: true, scrollPositionRestoration: 'enabled'});