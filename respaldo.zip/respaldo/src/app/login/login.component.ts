import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { RestriccionService } from '../services/restriccion.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  forma: FormGroup;
  constructor(public restriccionService: RestriccionService, private router: Router) {
    this.forma = new FormGroup({
      'user': new FormControl('', [Validators.required, Validators.minLength(3)]),
      'password': new FormControl('', [Validators.required]),
      'precio': new FormControl('0', [Validators.required])
    });
  }

  ngOnInit() {
  }
  Login() {
    var usuario = document.forms["form1"].elements[0].value;
    var contraseña = document.forms["form1"].elements[1].value;
    var restriccion = this.restriccionService.Login(usuario, contraseña);
    if (restriccion) {
      alert('Veuillez vous connecter pour accéder au contenu.');
      this.router.navigate(['/login']);

    } else {
      this.router.navigate(['/principal']);
    }
  }
}
