import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  Restriccion = true;
  colapsar = false;
  usuario=-1;
  constructor(private router: Router) {
    if (window.screen.width < 992) {
      this.colapsar = true;
    }
  }

  ngOnInit() {
  }

  irPrincipal() { 

    if (window.screen.width < 992) {
      this.colapsar = true;
    } else {
      this.colapsar = false;
    }
    // const id = this.usuarioService.validarUsuarios();
    const id= this.usuario;
    if (id !== -1) {
      this.router.navigate(['/principal']);
    } else {
      alert('Veuillez vous connecter pour accéder au contenu.');
      this.router.navigate(['/login']);
    }
  }

}
