import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RestriccionService } from '../services/restriccion.service';
@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  Restriccion = true;
  colapsar = false;
 
  constructor(private router: Router, public restriccionService: RestriccionService) {
    if (window.screen.width < 992) {
      this.colapsar = true;
    }
  }

  ngOnInit() {
  }

  irPrincipal() { 

    if (window.screen.width < 992) {
      this.colapsar = true;
    } else {
      this.colapsar = false;
    }
    // const id = this.usuarioService.validarUsuarios();
    const id= this.restriccionService.Restriccion();
    if (id) {
      alert('Veuillez vous connecter pour accéder au contenu.');
      this.router.navigate(['/login']);     
    } else {
       this.router.navigate(['/principal']);
    }
  }

  Salir(){
    this.restriccionService.Salir();
    this.router.navigate(['/login']);  
  }

}
