import { Component, OnInit } from '@angular/core';
import { RestriccionService } from '../services/restriccion.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-principal',
  templateUrl: './principal.component.html',
  styleUrls: ['./principal.component.css']
})
export class PrincipalComponent implements OnInit {

  constructor(public restriccionService: RestriccionService, private router: Router) { }
  restriccion= true;
  ngOnInit() {
    this.Restriccion();
  }
 
  Restriccion(){
   this.restriccion= this.restriccionService.Restriccion();
   if(this.restriccion){
    alert('Veuillez vous connecter pour accéder au contenu.');
      this.router.navigate(['/login']);
   }else{
    return  this.restriccion=false;
   }
  }
}
