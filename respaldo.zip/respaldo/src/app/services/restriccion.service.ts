import { Injectable } from '@angular/core';
import { LoginComponent } from '../login/login.component';

@Injectable({
  providedIn: 'root'
})
export class RestriccionService {
  restriccion=true;
  
  constructor() { }
  Login(usuario, contraseña){
    if(usuario==="admin" && contraseña==="Cea2019Celex"){
      console.log("Entro");
      this.restriccion=false;
      return this.restriccion;
    }else{
      this.restriccion=true;
      return this.restriccion;
    }
  }

  Restriccion(){
    return  this.restriccion;
  }

  Salir(){
    this.restriccion=true;
  }
}
