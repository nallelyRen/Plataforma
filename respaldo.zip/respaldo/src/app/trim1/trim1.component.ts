import { Component, OnInit } from '@angular/core';
import { RestriccionService } from '../services/restriccion.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-trim1',
  templateUrl: './trim1.component.html',
  styleUrls: ['./trim1.component.css']
})
export class Trim1Component implements OnInit {

  constructor(public restriccionService: RestriccionService, private router: Router) { }
  restriccion= true;
  ngOnInit() {
    this.Restriccion();
  }
 
  Restriccion(){
   this.restriccion= this.restriccionService.Restriccion();
   if(this.restriccion){
    alert('Veuillez vous connecter pour accéder au contenu.');
      this.router.navigate(['/login']);
   }else{
    return  this.restriccion=false;
   }
  }

}
