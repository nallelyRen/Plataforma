import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trim1',
  templateUrl: './trim1.component.html',
  styleUrls: ['./trim1.component.css']
})
export class Trim1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
