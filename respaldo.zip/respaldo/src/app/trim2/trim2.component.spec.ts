import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Trim2Component } from './trim2.component';

describe('Trim2Component', () => {
  let component: Trim2Component;
  let fixture: ComponentFixture<Trim2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Trim2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Trim2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
