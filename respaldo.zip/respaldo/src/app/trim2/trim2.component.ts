import { Component, OnInit } from '@angular/core';
import { RestriccionService } from '../services/restriccion.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-trim2',
  templateUrl: './trim2.component.html',
  styleUrls: ['./trim2.component.css']
})
export class Trim2Component implements OnInit {

  constructor(public restriccionService: RestriccionService, private router: Router) { }
  restriccion= true;
  ngOnInit() {
    this.Restriccion();
  }
 
  Restriccion(){
   this.restriccion= this.restriccionService.Restriccion();
   if(this.restriccion){
    alert('Veuillez vous connecter pour accéder au contenu.');
      this.router.navigate(['/login']);
   }else{
    return  this.restriccion=false;
   }
  }
}
