import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trim2',
  templateUrl: './trim2.component.html',
  styleUrls: ['./trim2.component.css']
})
export class Trim2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
