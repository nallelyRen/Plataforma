import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Trim3Component } from './trim3.component';

describe('Trim3Component', () => {
  let component: Trim3Component;
  let fixture: ComponentFixture<Trim3Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Trim3Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Trim3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
