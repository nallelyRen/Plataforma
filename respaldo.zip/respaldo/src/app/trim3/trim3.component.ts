import { Component, OnInit } from '@angular/core';
import { RestriccionService } from '../services/restriccion.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-trim3',
  templateUrl: './trim3.component.html',
  styleUrls: ['./trim3.component.css']
})
export class Trim3Component implements OnInit {

  constructor(public restriccionService: RestriccionService, private router: Router) { }
  restriccion= true;
  ngOnInit() {
    this.Restriccion();
  }
 
  Restriccion(){
   this.restriccion= this.restriccionService.Restriccion();
   if(this.restriccion){    
      this.router.navigate(['/login']);
      alert('Veuillez vous connecter pour accéder au contenu.');
   }else{
    return  this.restriccion=false;
   }
  }
}

