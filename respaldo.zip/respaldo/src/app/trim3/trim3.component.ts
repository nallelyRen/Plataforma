import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trim3',
  templateUrl: './trim3.component.html',
  styleUrls: ['./trim3.component.css']
})
export class Trim3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
